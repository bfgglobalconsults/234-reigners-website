import React from 'react'
import Image from 'next/image'

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
        <nav className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-red-500 via-yellow-500 to-green-500 rounded-full"></div>
            <span className="font-bold text-lg">234REIGNERS</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#" className="text-gray-700 hover:text-gray-900">
              Services
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900">
              Our Approach
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900">
              About
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900">
              Contact
            </a>
          </div>
          <button className="bg-gold hover:bg-gold-dark text-white px-6 py-2 rounded-full transition">
            Book a Discovery Call
          </button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-gray-900 to-gray-800 text-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center gap-2 text-sm mb-6">
            <span className="text-gold">🏠</span>
            <span>Welcome Home</span>
          </div>
          <h1 className="text-6xl md:text-7xl font-serif mb-6">
            Let's make something
            <br />
            <span className="text-gold">happen</span>
          </h1>
          <p className="text-gray-300 max-w-2xl text-lg">
            We offer a world-class cultural experience. Our mission is to bring culture to life
            through immersive experiences that connect people.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-cream">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-900 mb-2">500+</div>
            <div className="text-sm text-gray-600">Cultural Experiences</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-900 mb-2">50+</div>
            <div className="text-sm text-gray-600">Countries Reached</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-900 mb-2">10K+</div>
            <div className="text-sm text-gray-600">Happy Participants</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-900 mb-2">15+</div>
            <div className="text-sm text-gray-600">Years of Experience</div>
          </div>
        </div>
      </section>

      {/* Conversation Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16">
          <div>
            <div className="text-gold text-sm mb-4">START A CHAT</div>
            <h2 className="text-4xl font-serif mb-6">
              Let's Start a<br />
              <span className="text-gold">Conversation</span>
            </h2>
            <p className="text-gray-600 mb-8">
              We're passionate about creating meaningful cultural experiences. Whether you're
              looking to host a workshop, dining experience, or live entertainment, we're here to
              help bring your vision to life.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">📧</span>
                </div>
                <div>
                  <div className="font-semibold mb-1">Email</div>
                  <div className="text-gray-600">hello@234reigners.com</div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">📱</span>
                </div>
                <div>
                  <div className="font-semibold mb-1">Phone</div>
                  <div className="text-gray-600">+234 (0) 123 456 7890</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-cream p-8 rounded-2xl">
            <h3 className="text-2xl font-serif mb-6">Send Us a Message</h3>
            <form className="space-y-4">
              <input
                type="text"
                placeholder="Your Name"
                className="w-full px-4 py-3 bg-white rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-gold"
              />
              <input
                type="email"
                placeholder="Your Email"
                className="w-full px-4 py-3 bg-white rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-gold"
              />
              <textarea
                placeholder="Your Message"
                rows={4}
                className="w-full px-4 py-3 bg-white rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-gold"
              ></textarea>
              <button
                type="submit"
                className="w-full bg-gold hover:bg-gold-dark text-white py-3 rounded-lg transition font-semibold"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Quick Answers Section */}
      <section className="py-20 bg-cream">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-gold text-sm mb-4">FREQUENTLY ASKED</div>
            <h2 className="text-4xl font-serif mb-4">Quick answers</h2>
            <p className="text-gray-600">
              Everything you need to know about our cultural experiences
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                q: 'How do I book an event?',
                a: "Simply fill out our contact form or give us a call. We'll discuss your needs and create a custom experience.",
              },
              {
                q: 'Do you host outside outside the UK?',
                a: 'Yes! We offer experiences globally and can travel to your location.',
              },
              {
                q: 'Can I edit once online?',
                a: "Absolutely. We're flexible and can adjust details up until the event date.",
              },
              {
                q: 'How do you handle the event?',
                a: 'We manage everything from planning to execution, ensuring a seamless experience.',
              },
              {
                q: 'What is your typical response time?',
                a: 'We typically respond within 24 hours on business days.',
              },
              {
                q: 'Do you work with partner and credits?',
                a: 'Yes, we collaborate with various partners and accept multiple payment methods.',
              },
            ].map((faq, i) => (
              <div key={i} className="bg-white p-6 rounded-xl">
                <h3 className="font-semibold mb-3">{faq.q}</h3>
                <p className="text-gray-600 text-sm">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-forest to-forest-dark text-white relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-6 text-center relative z-10">
          <div className="text-gold text-sm mb-4">READY TO BEGIN?</div>
          <h2 className="text-4xl md:text-5xl font-serif mb-6">Book a discovery call</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Schedule a 30-minute call with our team. We'll learn about your vision and show you how
            we can bring it to life through authentic cultural experiences.
          </p>
          <button className="bg-gold hover:bg-gold-dark text-white px-8 py-4 rounded-full transition font-semibold">
            Schedule Call
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy text-white py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-red-500 via-yellow-500 to-green-500 rounded-full"></div>
                <span className="font-bold">234REIGNERS</span>
              </div>
              <p className="text-gray-400 text-sm">
                Bringing culture to life through immersive experiences.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    Our Services
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Cultural Workshops
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Dining Experiences
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Live Entertainment
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <a href="#" className="hover:text-white">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Our Story
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Our Team
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white">
                    Press
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>hello@234reigners.com</li>
                <li>+234 (0) 123 456 7890</li>
                <li>Lagos, Nigeria</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2026 234REIGNERS. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
